# Aria — setup guide

A real, buildable Android project. It has five working pieces:

1. **App blocking** — watches which app is in the foreground; if it's on your blocked list, it throws up a full-screen block where you have to plead your case to Aria in chat. She reads your stated goal and your excuse and decides whether to let you in (10-minute pass) or send you back.
2. **Location** — a foreground service that keeps a rolling last-known location using Google's Fused Location API.
3. **Floating bubble + mini voice chat** — a draggable companion icon over other apps; tap it and a small panel opens where you talk out loud and she answers out loud, no typing, without leaving whatever app you're in.
4. **Schedule awareness** — reads your phone's calendar (read-only) so she can factor in what's coming up today.
5. **Chat, powered by Claude** — calls the real Anthropic API using your own key.

Nothing here can read data *inside* other apps, and none of it works without you personally granting each permission on the device — Android doesn't allow silent access to any of it, by design.

---

## Building this with only a phone/tablet (no computer)

You don't need Android Studio at all for this — GitHub will compile the APK for you in the cloud, and you download the finished file straight to your phone.

1. **Create a free GitHub account** at github.com (works fine in your phone's browser).
2. **Create a new repository** — tap the "+" → "New repository" → name it `AriaApp` → Create.
3. **Get the project files into it.** Easiest phone-friendly way:
   - On your phone, extract the `AriaApp.zip` you already have (most phone Files apps have "Extract" or "Unzip" built in).
   - In your new GitHub repo, tap **Add file → Upload files**. Select all the extracted files/folders at once — Chrome on Android supports picking a whole folder here. If your browser only lets you pick individual files (Safari on iPad, some pickers), upload folder by folder — `app`, then `.github`, then the loose root files (`build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`) — GitHub preserves the paths you had open when you upload from within a folder view.
   - Commit the upload (there's a "Commit changes" button at the bottom).
4. **The build starts automatically.** This repo includes `.github/workflows/build.yml`, which GitHub runs the moment you push files to it — it compiles the whole app in the cloud.
5. **Watch it build**: tap the **Actions** tab at the top of your repo. You'll see a run in progress (yellow dot → green check when done, ~3-5 minutes).
6. **Download the APK**: once it's green, tap into that run, scroll to **Artifacts**, and tap `Aria-debug-apk`. It downloads as a `.zip` containing `app-debug.apk` — extract it with your phone's Files app.
7. **Install it**: tap the extracted `app-debug.apk` in your Files app. Android will ask you to allow installs from this source the first time — allow it, then Install. (This is a debug build, unsigned by a store, so Android will warn you it's from an "unknown source" — that's expected for a personal sideloaded app, not a sign anything's wrong.)

If step 3's folder upload doesn't cooperate in your browser, the fallback that always works: in your GitHub repo, use **Add file → Create new file**, type the path (e.g. `app/src/main/AndroidManifest.xml`) which auto-creates the folders, and paste in that file's content from the zip. Tedious with this many files, but 100% reliable from just a phone.

---

## If you ever do get access to a computer instead

## 1. Install Android Studio

1. Download Android Studio from `developer.android.com/studio` and install it.
2. On first launch, let it install the Android SDK (it'll prompt you — accept the defaults).
3. You need a phone running **Android 8.0 (API 26) or newer**.

## 2. Open the project

1. Unzip this project folder.
2. In Android Studio: **File → Open** → select the unzipped `AriaApp` folder.
3. Let it sync (bottom status bar). If it asks to create a Gradle wrapper or update the Gradle plugin, accept — first sync can take a few minutes.

## 3. Connect your phone

1. On your phone: **Settings → About phone → tap "Build number" 7 times** to unlock Developer Options.
2. **Settings → Developer options → enable USB debugging.**
3. Plug your phone into your computer with a USB cable. Accept the "Allow USB debugging?" prompt on the phone.
4. In Android Studio, your phone should appear in the device dropdown at the top. Select it.

## 4. Build and install

Click the green ▶ Run button in Android Studio (or `Shift+F10`). It'll compile and install Aria on your phone directly. This takes a minute the first time.

## 5. Get an Anthropic API key

The chat needs to talk to Claude directly from your phone — a compiled app can't use the free connection this conversation has.

1. Go to `console.anthropic.com`, sign up, and create an API key.
2. Add a small amount of credit (a few dollars covers a very long time of casual chatting).
3. Open the Aria app → paste the key into **Anthropic API key** in the main screen → tap **Save**.

Your key is stored only on your phone (`SharedPreferences`) and is sent straight from your phone to `api.anthropic.com` — it doesn't pass through us or anyone else.

## 6. Set your goal

In the main screen, fill in **"What are you supposed to be doing?"** — this is what Aria checks your excuses against when you try to open a blocked app. Be specific ("studying for my chemistry final Friday") — vague goals make for vague judgment calls.

## 7. Choose apps to block

Tap **Choose apps to block** and check the ones you want gated (TikTok, Instagram, YouTube, games, whatever pulls you off track).

## 8. Grant permissions, in order

The main screen has seven buttons that take you straight to the right settings page:

1. **Usage access** — Settings → find Aria in the list → toggle it on. This is how Aria sees which app is currently open (nothing more — she can't see what's *inside* it).
2. **Display over other apps** — needed for the block screen and the floating bubble.
3. **Location** — standard Android permission dialog.
4. **Notifications** — needed on Android 13+ so the "Aria is watching over your focus" persistent notification can show (Android requires foreground services to show one — it's not optional, it's how Android tells you a background service is running).
5. **Microphone** — standard Android permission dialog, needed for the voice bubble.
6. **Calendar** — standard Android permission dialog, lets Aria factor your schedule into what she says.
7. **Ignore battery optimization** — without this, Android may kill the background service after a while and blocking will silently stop working.

## 9. Flip the switch

Toggle **Protection active** on the main screen. Try opening a blocked app — you should get the plea screen.

---

## Honest limitations

- **This only sees which app is in front, never what's inside it.** No app on an unmodified Android phone can read another app's screen content or data — that boundary is enforced by the OS itself.
- **Detection has a small delay** (up to ~1.5 seconds) since it polls rather than hooking every app switch.
- **If you publish this to the Play Store**, apps with usage-access + overlay + background location together get manually reviewed and often rejected or restricted unless you write a clear privacy policy and justify each permission — that review process is designed to stop exactly this kind of app from being used for spying on someone *else's* phone. For your own personal device, sideloading it via USB debugging (what step 4 does) sidesteps that entirely, which is why this guide has you do it that way rather than publishing.
- **Battery use** will be higher than a normal app because of the two persistent foreground services (usage polling + location). The "ignore battery optimization" step in #8 helps this run reliably, but it will cost you some battery life.
- **Voice recognition and calendar reading both need their own permission grant** (buttons 5 and 6) — the mic uses Android's on-device `SpeechRecognizer`, and nothing you say is stored anywhere except sent as text to Claude for that one reply.

## Where to extend it

- `BlockScreenActivity.kt` — the judging prompt sent to Claude. Tune the tone/strictness here.
- `UsageMonitorService.kt` — swap the polling interval, or add an `AccessibilityService` instead for instant detection if you want to go further.
- `OverlayBubbleService.kt` — currently just opens the main app on tap; wire it to a mini popup chat window if you want to talk to Aria without leaving whatever app you're in.
