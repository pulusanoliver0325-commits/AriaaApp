package com.aria.companion.blocking

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.aria.companion.R
import com.aria.companion.network.ClaudeClient
import com.aria.companion.prefs.AppPrefs

class BlockScreenActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PACKAGE = "extra_package"
    }

    private lateinit var prefs: AppPrefs
    private lateinit var pkg: String
    private lateinit var chatContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_block)
        prefs = AppPrefs(this)
        pkg = intent.getStringExtra(EXTRA_PACKAGE) ?: run { finish(); return }

        val appLabel = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) { pkg }

        findViewById<TextView>(R.id.blockedAppName).text = "$appLabel is blocked right now"
        findViewById<TextView>(R.id.goalReminder).text =
            if (prefs.studyGoal.isNotBlank()) "You told her: ${prefs.studyGoal}" else "You haven't told her a goal yet — set one in Settings."

        chatContainer = findViewById(R.id.chatContainer)
        addBubble("Why do you need $appLabel right now?", isHer = true)

        val input = findViewById<EditText>(R.id.pleaInput)
        findViewById<android.widget.Button>(R.id.pleaSendBtn).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isBlank()) return@setOnClickListener
            addBubble(text, isHer = false)
            input.text.clear()
            askAria(text, appLabel)
        }

        findViewById<android.widget.Button>(R.id.goBackBtn).setOnClickListener {
            val home = Intent(Intent.ACTION_MAIN).apply { addCategory(Intent.CATEGORY_HOME) }
            startActivity(home)
            finish()
        }
    }

    private fun askAria(pleaText: String, appLabel: String) {
        if (prefs.apiKey.isBlank()) {
            addBubble("I don't have an API key yet — add one in Settings so I can actually think this through with you.", isHer = true)
            return
        }
        val thinking = addBubble("...", isHer = true)

        val system = """
            You are ${prefs.companionName}, a warm but firm accountability companion.
            The user set this goal: "${prefs.studyGoal.ifBlank { "no goal set" }}"
            They are asking to be let into a blocked app called "$appLabel" and just gave you their reason.
            Decide: APPROVE only if the reason is a genuinely legitimate, specific need connected to their goal or a real
            practical necessity (e.g. "I need Maps app" style logic, or a short specific reason that isn't just wanting
            to relax/scroll). Otherwise DENY, gently but not harshly, and redirect them back to their goal.
            Respond in 1-3 warm sentences. Then on a new final line write exactly one of:
            DECISION: APPROVE
            or
            DECISION: DENY
        """.trimIndent()

        ClaudeClient.send(prefs.apiKey, system, pleaText) { reply ->
            runOnUiThread {
                chatContainer.removeView(thinking)
                if (reply == null) {
                    addBubble("I couldn't reach the network just now — try again.", isHer = true)
                    return@runOnUiThread
                }
                val approved = reply.contains("DECISION: APPROVE")
                val visibleText = reply.replace(Regex("DECISION:\\s*(APPROVE|DENY)"), "").trim()
                addBubble(visibleText.ifBlank { if (approved) "Okay, go ahead." else "Not this time." }, isHer = true)

                if (approved) {
                    prefs.setUnlockedUntil(pkg, System.currentTimeMillis() + 10 * 60 * 1000)
                    val launch = packageManager.getLaunchIntentForPackage(pkg)
                    if (launch != null) startActivity(launch)
                    finish()
                }
            }
        }
    }

    private fun addBubble(text: String, isHer: Boolean): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.setPadding(28, 20, 28, 20)
        tv.setTextColor(getColor(R.color.ink))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = 32f
        bg.setColor(getColor(if (isHer) R.color.bg2 else R.color.violetSoft))
        tv.background = bg
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 0, 0, 16)
        params.gravity = if (isHer) Gravity.START else Gravity.END
        tv.layoutParams = params
        chatContainer.addView(tv)
        return tv
    }
}
