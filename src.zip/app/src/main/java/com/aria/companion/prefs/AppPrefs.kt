package com.aria.companion.prefs

import android.content.Context

/**
 * Single place for all persisted settings. Nothing here is uploaded anywhere
 * except the API key + your plea text, which go straight to Anthropic's API
 * when you ask Aria to unblock something (see ClaudeClient).
 */
class AppPrefs(context: Context) {

    private val sp = context.getSharedPreferences("aria_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(value) = sp.edit().putString("api_key", value).apply()

    var studyGoal: String
        get() = sp.getString("goal", "") ?: ""
        set(value) = sp.edit().putString("goal", value).apply()

    var companionName: String
        get() = sp.getString("companion_name", "Aria") ?: "Aria"
        set(value) = sp.edit().putString("companion_name", value).apply()

    var protectionEnabled: Boolean
        get() = sp.getBoolean("protection_enabled", false)
        set(value) = sp.edit().putBoolean("protection_enabled", value).apply()

    var blockedPackages: MutableSet<String>
        get() = HashSet(sp.getStringSet("blocked_packages", emptySet()) ?: emptySet())
        set(value) = sp.edit().putStringSet("blocked_packages", value).apply()

    fun addBlocked(pkg: String) {
        val s = blockedPackages; s.add(pkg); blockedPackages = s
    }

    fun removeBlocked(pkg: String) {
        val s = blockedPackages; s.remove(pkg); blockedPackages = s
    }

    // package name -> epoch millis until which it's temporarily unlocked
    fun unlockedUntil(pkg: String): Long = sp.getLong("unlock_$pkg", 0L)

    fun setUnlockedUntil(pkg: String, untilMillis: Long) {
        sp.edit().putLong("unlock_$pkg", untilMillis).apply()
    }

    var lastKnownLocation: String
        get() = sp.getString("last_location", "not yet available") ?: "not yet available"
        set(value) = sp.edit().putString("last_location", value).apply()
}
