package com.aria.companion.blocking

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.aria.companion.MainActivity
import com.aria.companion.R
import com.aria.companion.prefs.AppPrefs

/**
 * Polls UsageStatsManager every 1.5s for the current foreground app.
 * If it's on the blocked list and not within a temporary unlock window,
 * launches BlockScreenActivity on top of it.
 *
 * This uses polling rather than an AccessibilityService because it's simpler
 * to reason about and doesn't require declaring broad accessibility intent —
 * but it does mean detection can lag by up to ~1.5s, and it only sees the
 * single foreground app, never any content inside it.
 */
class UsageMonitorService : Service() {

    private lateinit var prefs: AppPrefs
    private val handler = Handler(Looper.getMainLooper())
    private var lastBlockedLaunch = 0L

    private val poll = object : Runnable {
        override fun run() {
            checkForegroundApp()
            handler.postDelayed(this, 1500)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        startForeground(1, buildNotification())
        handler.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(poll)
    }

    private fun checkForegroundApp() {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - 10_000
        val events = usm.queryEvents(begin, end)
        var lastPkg: String? = null
        val event = android.app.usage.UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        val pkg = lastPkg ?: return
        if (pkg == packageName) return // don't block our own UI

        if (prefs.blockedPackages.contains(pkg)) {
            val unlockedUntil = prefs.unlockedUntil(pkg)
            if (System.currentTimeMillis() < unlockedUntil) return // temporarily allowed

            // debounce so we don't spam-launch the block screen every poll tick
            if (System.currentTimeMillis() - lastBlockedLaunch < 2000) return
            lastBlockedLaunch = System.currentTimeMillis()

            val i = Intent(this, BlockScreenActivity::class.java).apply {
                putExtra(BlockScreenActivity.EXTRA_PACKAGE, pkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(i)
        }
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "aria_monitor"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Aria protection", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java)
        val pi = android.app.PendingIntent.getActivity(
            this, 0, openIntent,
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Aria is watching over your focus")
            .setSmallIcon(R.drawable.ic_face)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
