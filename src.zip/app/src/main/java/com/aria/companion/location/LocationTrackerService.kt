package com.aria.companion.location

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.aria.companion.MainActivity
import com.aria.companion.R
import com.aria.companion.prefs.AppPrefs
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * Keeps a rolling "last known location" so Aria can factor in where you are
 * (e.g. "you're at the library" vs "you're at the mall") if you build that
 * into her prompt later. Right now it just stores it — nothing is sent
 * anywhere unless you wire it into a ClaudeClient call yourself.
 */
class LocationTrackerService : Service() {

    private lateinit var prefs: AppPrefs
    private val fusedClient by lazy { LocationServices.getFusedLocationProviderClient(this) }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val loc = result.lastLocation ?: return
            prefs.lastKnownLocation = "${loc.latitude}, ${loc.longitude}"
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        startForeground(2, buildNotification())

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED
        ) {
            val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 60_000L).build()
            fusedClient.requestLocationUpdates(request, callback, Looper.getMainLooper())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        super.onDestroy()
        fusedClient.removeLocationUpdates(callback)
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "aria_location"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Aria location", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Aria has location access on")
            .setSmallIcon(R.drawable.ic_face)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
