package com.aria.companion.ui

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.aria.companion.R
import com.aria.companion.prefs.AppPrefs

class InstalledAppsAdapter(
    private val apps: List<ApplicationInfo>,
    private val pm: PackageManager,
    private val prefs: AppPrefs
) : RecyclerView.Adapter<InstalledAppsAdapter.VH>() {

    class VH(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.appIcon)
        val name: TextView = itemView.findViewById(R.id.appName)
        val check: CheckBox = itemView.findViewById(R.id.appCheck)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(pm.getApplicationIcon(app))
        holder.name.text = pm.getApplicationLabel(app)
        holder.check.setOnCheckedChangeListener(null)
        holder.check.isChecked = prefs.blockedPackages.contains(app.packageName)
        holder.check.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) prefs.addBlocked(app.packageName) else prefs.removeBlocked(app.packageName)
        }
        holder.itemView.setOnClickListener { holder.check.toggle() }
    }

    override fun getItemCount() = apps.size
}
