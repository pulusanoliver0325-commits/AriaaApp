package com.aria.companion.ui

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aria.companion.R
import com.aria.companion.prefs.AppPrefs

class AppListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)

        val prefs = AppPrefs(this)
        val pm = packageManager

        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName } // don't let Aria block herself
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || pm.getLaunchIntentForPackage(it.packageName) != null }
            .distinctBy { it.packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val recycler = findViewById<RecyclerView>(R.id.appRecycler)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = InstalledAppsAdapter(apps, pm, prefs)
    }
}
