package com.aria.companion.companion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.aria.companion.MainActivity
import com.aria.companion.R
import com.aria.companion.calendar.CalendarHelper
import com.aria.companion.network.ClaudeClient
import com.aria.companion.prefs.AppPrefs
import java.util.Locale

/**
 * A draggable bubble that floats over other apps. Tapping it opens a small
 * voice-only chat panel right there -- no need to leave whatever app you're
 * in. Talk, she answers out loud. Drag still moves the bubble.
 */
class OverlayBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: AppPrefs
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        startForeground(3, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { }
        addBubble()
    }

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        var initialX = 0; var initialY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel(params)
                    true
                }
                else -> false
            }
        }
        windowManager.addView(view, params)
    }

    private fun togglePanel(bubbleParams: WindowManager.LayoutParams) {
        if (panelView != null) {
            closePanel()
            return
        }
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_chat_panel, null)
        panelView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams.x
        params.y = bubbleParams.y + 90

        view.findViewById<TextView>(R.id.panelClose).setOnClickListener { closePanel() }
        view.findViewById<ImageView>(R.id.panelMic).setOnClickListener { startListening(view) }

        windowManager.addView(view, params)
    }

    private fun closePanel() {
        recognizer?.stopListening()
        panelView?.let { windowManager.removeView(it) }
        panelView = null
    }

    private fun startListening(panel: View) {
        val status = panel.findViewById<TextView>(R.id.panelStatus)
        val reply = panel.findViewById<TextView>(R.id.panelReply)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "voice recognition not available on this device"
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "thinking..." }
            override fun onError(error: Int) { status.text = "didn't catch that -- tap to try again" }
            override fun onResults(results: Bundle?) {
                val said = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: return
                askAria(said, status, reply)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }
        recognizer?.startListening(intent)
    }

    private fun askAria(said: String, status: TextView, reply: TextView) {
        if (prefs.apiKey.isBlank()) {
            reply.text = "Add your API key in the main app first."
            status.text = ""
            return
        }
        val schedule = CalendarHelper.todaysScheduleSummary(this)
        val system = """
            You are ${prefs.companionName}, a warm, upbeat voice companion.
            The user's goal right now: "${prefs.studyGoal.ifBlank { "not set" }}"
            Their schedule for the next 18 hours:
            $schedule
            Reply in 1-3 short spoken sentences -- this will be read aloud, so keep it natural and brief.
        """.trimIndent()

        ClaudeClient.send(prefs.apiKey, system, said) { text ->
            val response = text ?: "I couldn't reach the network just now."
            android.os.Handler(mainLooper).post {
                reply.text = response
                status.text = ""
                tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, "aria_reply")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { windowManager.removeView(it) }
        panelView?.let { windowManager.removeView(it) }
        recognizer?.destroy()
        tts?.shutdown()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun buildNotification(): android.app.Notification {
        val channelId = "aria_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Aria companion", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Aria is floating nearby")
            .setSmallIcon(R.drawable.ic_face)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
