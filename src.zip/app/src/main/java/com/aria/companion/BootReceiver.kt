package com.aria.companion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.aria.companion.blocking.UsageMonitorService
import com.aria.companion.location.LocationTrackerService
import com.aria.companion.prefs.AppPrefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = AppPrefs(context)
        if (prefs.protectionEnabled) {
            ContextCompat.startForegroundService(context, Intent(context, UsageMonitorService::class.java))
            ContextCompat.startForegroundService(context, Intent(context, LocationTrackerService::class.java))
        }
    }
}
