package com.aria.companion

import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.aria.companion.blocking.UsageMonitorService
import com.aria.companion.companion.OverlayBubbleService
import com.aria.companion.location.LocationTrackerService
import com.aria.companion.prefs.AppPrefs
import com.aria.companion.ui.AppListActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = AppPrefs(this)

        val apiKeyInput = findViewById<EditText>(R.id.apiKeyInput)
        val goalInput = findViewById<EditText>(R.id.goalInput)
        val statusText = findViewById<TextView>(R.id.statusText)
        val protectionSwitch = findViewById<SwitchMaterial>(R.id.protectionSwitch)

        apiKeyInput.setText(prefs.apiKey)
        goalInput.setText(prefs.studyGoal)
        protectionSwitch.isChecked = prefs.protectionEnabled

        findViewById<android.widget.Button>(R.id.saveBtn).setOnClickListener {
            prefs.apiKey = apiKeyInput.text.toString().trim()
            prefs.studyGoal = goalInput.text.toString().trim()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<android.widget.Button>(R.id.chooseAppsBtn).setOnClickListener {
            startActivity(Intent(this, AppListActivity::class.java))
        }

        findViewById<android.widget.Button>(R.id.grantUsageBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        findViewById<android.widget.Button>(R.id.grantOverlayBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        findViewById<android.widget.Button>(R.id.grantLocationBtn).setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                101
            )
        }
        findViewById<android.widget.Button>(R.id.grantNotifBtn).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33) {
                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 102)
            } else {
                Toast.makeText(this, "Not needed on this Android version", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<android.widget.Button>(R.id.grantMicBtn).setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.RECORD_AUDIO), 103)
        }
        findViewById<android.widget.Button>(R.id.grantCalendarBtn).setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.READ_CALENDAR), 104)
        }
        findViewById<android.widget.Button>(R.id.grantBatteryBtn).setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "Already exempt", Toast.LENGTH_SHORT).show()
            }
        }

        protectionSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.protectionEnabled = isChecked
            if (isChecked) startProtection() else stopProtection()
        }

        refreshStatus(statusText)
    }

    private fun startProtection() {
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Grant usage access first", Toast.LENGTH_LONG).show()
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, UsageMonitorService::class.java))
        ContextCompat.startForegroundService(this, Intent(this, LocationTrackerService::class.java))
        if (Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, Intent(this, OverlayBubbleService::class.java))
        }
    }

    private fun stopProtection() {
        stopService(Intent(this, UsageMonitorService::class.java))
        stopService(Intent(this, LocationTrackerService::class.java))
        stopService(Intent(this, OverlayBubbleService::class.java))
    }

    private fun hasUsageAccess(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun refreshStatus(statusText: TextView) {
        val micGranted = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        statusText.text = "Usage access: ${if (hasUsageAccess()) "granted" else "needed"}\n" +
            "Overlay permission: ${if (Settings.canDrawOverlays(this)) "granted" else "needed"}\n" +
            "Microphone: ${if (micGranted) "granted" else "needed"}\n" +
            "Last known location: ${prefs.lastKnownLocation}\n\n" +
            "Blocked apps: ${prefs.blockedPackages.size}"
    }

    override fun onResume() {
        super.onResume()
        refreshStatus(findViewById(R.id.statusText))
    }
}
