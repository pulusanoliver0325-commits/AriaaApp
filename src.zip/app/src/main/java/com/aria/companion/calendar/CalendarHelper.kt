package com.aria.companion.calendar

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

/**
 * Reads upcoming events from the device's calendar provider (whatever
 * calendars the user has synced — Google Calendar, Outlook, etc, however
 * they're set up in the Android Calendar app). Read-only, and only used to
 * give Aria context in her replies. Requires READ_CALENDAR permission.
 */
object CalendarHelper {

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) ==
            PackageManager.PERMISSION_GRANTED

    /** Returns a short human-readable summary of the next few events, for feeding into a prompt. */
    fun todaysScheduleSummary(context: Context): String {
        if (!hasPermission(context)) return "(calendar permission not granted)"

        val now = System.currentTimeMillis()
        val dayEnd = now + 18 * 60 * 60 * 1000 // next 18 hours

        val uriBuilder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(uriBuilder, now)
        ContentUris.appendId(uriBuilder, dayEnd)

        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END
        )

        val results = StringBuilder()
        val cursor = context.contentResolver.query(uriBuilder.build(), projection, null, null, "begin ASC")
        cursor?.use {
            val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
            var count = 0
            while (it.moveToNext() && count < 6) {
                val title = it.getString(0) ?: "Untitled event"
                val begin = it.getLong(1)
                results.append("- $title at ${fmt.format(Date(begin))}\n")
                count++
            }
        }
        return if (results.isEmpty()) "Nothing on the calendar in the next 18 hours." else results.toString()
    }
}
