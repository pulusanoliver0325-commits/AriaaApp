package com.aria.companion.schedule

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.provider.CalendarContract

object CalendarHelper {

    data class Event(val title: String, val startMillis: Long, val endMillis: Long)

    fun upcomingToday(context: Context): List<Event> {
        val results = mutableListOf<Event>()
        val now = System.currentTimeMillis()
        val endOfDay = now + (24 - java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) * 3600_000L

        val projection = arrayOf(
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END
        )

        val uriBuilder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(uriBuilder, now)
        ContentUris.appendId(uriBuilder, endOfDay)

        var cursor: Cursor? = null
        try {
            cursor = context.contentResolver.query(uriBuilder.build(), projection, null, null, "${CalendarContract.Instances.BEGIN} ASC")
            cursor?.use {
                while (it.moveToNext()) {
                    val title = it.getString(0) ?: "(untitled event)"
                    val begin = it.getLong(1)
                    val end = it.getLong(2)
                    results.add(Event(title, begin, end))
                }
            }
        } catch (e: SecurityException) {
            // permission not granted — caller gets an empty list
        }
        return results
    }

    fun summaryForPrompt(context: Context): String {
        val events = upcomingToday(context)
        if (events.isEmpty()) return "Nothing left on their calendar today (or calendar access isn't granted)."
        val fmt = java.text.SimpleDateFormat("h:mm a", java.util.Locale.getDefault())
        return events.joinToString("; ") { e ->
            "${fmt.format(java.util.Date(e.startMillis))} - ${e.title}"
        }
    }
}
