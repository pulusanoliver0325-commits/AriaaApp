package com.aria.companion.prefs

import android.content.Context

class AppPrefs(context: Context) {

    private val sp = context.getSharedPreferences("aria_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(value) = sp.edit().putString("api_key", value).apply()

    var studyGoal: String
        get() = sp.getString("goal", "") ?: ""
        set(value) = sp.edit().putString("goal", value).apply()

    var companionName: String
        get() = sp.getString("companion_name", "Aria") ?: "Aria"
        set(value) = sp.edit().putString("companion_name", value).apply()

    var protectionEnabled: Boolean
        get() = sp.getBoolean("protection_enabled", false)
        set(value) = sp.edit().putBoolean("protection_enabled", value).apply()

    var blockedPackages: MutableSet<String>
        get() = HashSet(sp.getStringSet("blocked_packages", emptySet()) ?: emptySet())
        set(value) = sp.edit().putStringSet("blocked_packages", value).apply()

    fun addBlocked(pkg: String) {
        val s = blockedPackages; s.add(pkg); blockedPackages = s
    }

    fun removeBlocked(pkg: String) {
        val s = blockedPackages; s.remove(pkg); blockedPackages = s
    }

    fun unlockedUntil(pkg: String): Long = sp.getLong("unlock_$pkg", 0L)

    fun setUnlockedUntil(pkg: String, untilMillis: Long) {
        sp.edit().putLong("unlock_$pkg", untilMillis).apply()
    }

    var lastKnownLocation: String
        get() = sp.getString("last_location", "not yet available") ?: "not yet available"
        set(value) = sp.edit().putString("last_location", value).apply()

    // ---- notes: a running log Aria keeps on you, fed back into her prompt each time ----

    var notes: String
        get() = sp.getString("notes_log", "") ?: ""
        set(value) = sp.edit().putString("notes_log", value).apply()

    /** Appends one line, trimming from the oldest end so the log never grows unbounded. */
    fun appendNote(line: String) {
        val stamp = java.text.SimpleDateFormat("MMM d, h:mm a", java.util.Locale.getDefault()).format(java.util.Date())
        val updated = (notes + "\n[$stamp] $line").trim()
        val lines = updated.split("\n")
        notes = if (lines.size > 40) lines.takeLast(40).joinToString("\n") else updated
    }
}
