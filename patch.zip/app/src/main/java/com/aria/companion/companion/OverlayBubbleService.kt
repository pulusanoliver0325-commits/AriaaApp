package com.aria.companion.companion

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.aria.companion.MainActivity
import com.aria.companion.R
import com.aria.companion.network.ClaudeClient
import com.aria.companion.prefs.AppPrefs
import com.aria.companion.schedule.CalendarHelper
import java.util.Locale

class OverlayBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: AppPrefs
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var breathingAnimator: android.animation.ValueAnimator? = null

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        startForeground(3, buildNotification())
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupTts()
        addBubble()
    }

    private fun setupTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val best = tts?.voices?.filter { it.locale == Locale.US && !it.isNetworkConnectionRequired }
                    ?.maxByOrNull { it.quality }
                if (best != null) tts?.voice = best
                tts?.setPitch(1.05f)
                tts?.setSpeechRate(1.0f)
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { setPulseSpeed(fast = true) }
            override fun onDone(utteranceId: String?) { setPulseSpeed(fast = false) }
            override fun onError(utteranceId: String?) { setPulseSpeed(fast = false) }
        })
    }

    private fun addBubble() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel(params)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, params)
        startBreathing(view)
    }

    private fun startBreathing(view: View) {
        val face = view.findViewById<ImageView>(R.id.bubbleFace) ?: view
        breathingAnimator?.cancel()
        val animator = android.animation.ValueAnimator.ofFloat(1.0f, 1.08f)
        animator.duration = 1400
        animator.repeatMode = android.animation.ValueAnimator.REVERSE
        animator.repeatCount = android.animation.ValueAnimator.INFINITE
        animator.interpolator = LinearInterpolator()
        animator.addUpdateListener {
            val scale = it.animatedValue as Float
            face.scaleX = scale
            face.scaleY = scale
        }
        animator.start()
        breathingAnimator = animator
    }

    private fun setPulseSpeed(fast: Boolean) {
        breathingAnimator?.duration = if (fast) 350 else 1400
    }

    private fun togglePanel(bubbleParams: WindowManager.LayoutParams) {
        if (panelView != null) {
            windowManager.removeView(panelView)
            panelView = null
            return
        }
        val inflater = LayoutInflater.from(this)
        val panel = inflater.inflate(R.layout.overlay_chat_panel, null)
        panelView = panel

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bubbleParams.x
        params.y = bubbleParams.y + 90

        val log = panel.findViewById<TextView>(R.id.panelReply)
        val status = panel.findViewById<TextView>(R.id.panelStatus)
        val mic = panel.findViewById<ImageView>(R.id.panelMic)
        val close = panel.findViewById<TextView>(R.id.panelClose)

        close.setOnClickListener {
            windowManager.removeView(panel)
            panelView = null
        }

        mic.setOnClickListener { startListening(log, status) }

        windowManager.addView(panel, params)
    }

    private fun startListening(log: TextView, status: TextView) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Voice isn't available on this device"
            return
        }
        status.text = "listening..."
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle) {
                val said = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                log.append("\nYou: $said")
                status.text = "thinking..."
                askAria(said, log, status)
            }
            override fun onError(error: Int) { status.text = "didn't catch that — tap to retry" }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        recognizer?.startListening(intent)
    }

    private fun askAria(said: String, log: TextView, status: TextView) {
        if (prefs.apiKey.isBlank()) {
            log.append("\nAria: I don't have an API key yet — add one in the main app.")
            status.text = ""
            return
        }
        val notesBlock = if (prefs.notes.isNotBlank()) "\n\nWhat you know about them:\n${prefs.notes}" else ""
        val schedule = CalendarHelper.summaryForPrompt(this)
        val system = """
            You are ${prefs.companionName}, a warm companion talking to the user through a small voice popup.
            Their goal: "${prefs.studyGoal.ifBlank { "no goal set" }}"$notesBlock
            Their schedule for the rest of today: $schedule
            Keep replies short (1-3 sentences) since this will be spoken aloud.
        """.trimIndent()

        ClaudeClient.send(prefs.apiKey, system, said) { reply ->
            android.os.Handler(mainLooper).post {
                status.text = ""
                val text = reply ?: "Sorry, I couldn't reach the network."
                log.append("\nAria: $text")
                if (!text.startsWith("NETERR:")) speak(text)
            }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aria_utt")
    }

    override fun onDestroy() {
        super.onDestroy()
        bubbleView?.let { windowManager.removeView(it) }
        panelView?.let { windowManager.removeView(it) }
        breathingAnimator?.cancel()
        tts?.shutdown()
        recognizer?.destroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun buildNotification(): android.app.Notification {
        val channelId = "aria_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Aria companion", NotificationManager.IMPORTANCE_MIN)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val pi = android.app.PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Aria is floating nearby")
            .setSmallIcon(R.drawable.ic_face)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
